create function pg_catalog.col_description(oid, integer) returns text
STABLE
LANGUAGE SQL
AS $$
select description from pg_catalog.pg_description where objoid = $1 and classoid = 'pg_catalog.pg_class'::pg_catalog.regclass and objsubid = $2
$$;
